class HiveConstantValue {


}